﻿Title: IoT Gateway
Description: Main page of the IoT Gateway
Date: 2016-02-02
Author: Peter Waher
Copyright: Copyright.md
Master: Master.md

==================================       ======================================

Welcome to the IoT Gateway
=============================

![Kermit](http://vignette1.wikia.nocookie.net/characters/images/9/98/Kermit-two1.jpg)

The web server hosts any type of content under the `Root` folder. [Markdown](Markdown.md) content (files with extensions `.md` or `.markdown`) will 
automatically be converted to HTML if viewed by a browser. To retrieve the markdown file as-is, make sure the `HTTP GET` method includes 
`Accept: text/markdown` in its header.