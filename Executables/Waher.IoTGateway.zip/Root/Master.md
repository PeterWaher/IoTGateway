﻿Title: IoT Gateway Menu
Description: Main menu of the IoT Gateway
Date: 2016-02-08
Author: Peter Waher
Copyright: Copyright.md
CSS: /WaherDataAB.css

<header>
<nav>

* [Home](/index.md)
* [Markdown](/Markdown.md)
* [License](/Copyright.md)
* [IoT Gateway](https://github.com/PeterWaher/IoTGateway)
* [Waher Data](http://waher.se/)

</nav>
</header>
<main>

[%Details]

</main>
<footer>
<span>
This page is hosted by [**IoT Gateway**](https://github.com/PeterWaher/IoTGateway). (c) [Waher Data AB](http://waher.se/) 2015-2016.
</span>
</footer>
